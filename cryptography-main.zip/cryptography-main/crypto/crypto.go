package crypto

import (
	"errors"
)

var ErrInvalidKey = errors.New("invalid key length")
